## Dictionary

 A Linux tool for helping you learn Spanish. It is a tool that may be useful in helping people 
to learn a new language by memorizing frazes, words, greetings, etc.

# Packeges requierd:

  1. Python >=3
  2. PyQt4
  3. Pyaudio 

**In order to run the program you need to run spaniola.py from the terminal**


[Pyaudio](https://people.csail.mit.edu/hubert/pyaudio/)

# Demonstration

![My Image](https://github.com/cristiangabor/dictionary/blob/master/demonstration/demo.gif)
